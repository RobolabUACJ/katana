
#include "adc.h"
#include "sensores.h"


void CalibrarAccel(void)
{
    float raccx=0,raccy=0;
    unsigned int vaccx=0, vaccy=0, i=0;

    do{

        vaccx= vaccx + saccx;
        vaccy= vaccy + saccy;
        i++;

    }while(i!=0x0400);

    vaccx= vaccx>>10;
    vaccy= vaccy>>10;

    raccx= (vaccx * 0.003204102 );
    raccy= (vaccy * 0.003204102 );

    ref.raccx= raccx;
    ref.raccy= raccy;



}

void CalibrarGyro(void)
{
    float rgyro=0;
    unsigned int vgyro=0,j=0;

     do{

        vgyro= vgyro + sgyro;

        j++;

    }while(j!=0x0400);

    vgyro= vgyro>>10;

    rgyro= (vgyro * 0.003204102 );

    //0.003204102     3.281/1024
    //0.003222656     3.3/1024

    ref.rgyro= rgyro;
}




float Aceleracion(calibrar ref)
{
    float accx, accy;
    unsigned int filtrox=0,filtroy=0;
    unsigned short k=0;

    do
    {
        filtrox= filtrox + saccx;
        filtroy= filtroy + saccy;
        k++;

    }while(k != 0x40);

        filtrox= filtrox>>6;
        filtroy= filtroy>>6;


    accx= (filtrox * 0.003204102 );
    accy= (filtroy * 0.003204102 );

    accx= accx-ref.raccx;
    accy= accy-ref.raccy;
    
   if((accx <= .007) && (accx >= -.007)) accx=0;
   if((accy <= .007) && (accy >= -.007)) accy=0;

    sensores.accx.vaccx= (accx * 9.81);
    sensores.accy.vaccy= (accy * 9.81);

    // el acelerometro da su salida en gravedades 1g = 9.81 m/s^2

    INPacket[1]= sensores.accx.daccx[0];
    INPacket[2]= sensores.accx.daccx[1];
    INPacket[3]= sensores.accx.daccx[2];
    INPacket[4]= sensores.accx.daccx[3];

    INPacket[5]= sensores.accy.daccy[0];
    INPacket[6]= sensores.accy.daccy[1];
    INPacket[7]= sensores.accy.daccy[2];
    INPacket[8]= sensores.accy.daccy[3]; 


}

float Gyro(float rgyro)
{
    float gyro;
    short i=0;
    unsigned int filtro=0;

    do
    {
         filtro= filtro + sgyro;
         i++;

    }while(i != 0x40);
       
    filtro= filtro>>6;

    gyro= (filtro *0.003204102 );

    gyro= gyro-rgyro;

    gyro= gyro/.015;

    if((gyro <= .7) && (gyro >= -.7)) gyro=0;

    sensores.gyro.vgyro= gyro;


   INPacket[9]= sensores.gyro.dgyro[0];
   INPacket[10]= sensores.gyro.dgyro[1];
   INPacket[11]= sensores.gyro.dgyro[2];
   INPacket[12]= sensores.gyro.dgyro[3]; 


    return gyro;
}

float Temperatura(void)
{
    float temp;
    unsigned char i;
    int valor=0;

    do
    {
        valor= valor + stemp;
        i++;

    }while(i != 0x40);
    

    valor= valor>>6;

    temp= (valor * 0.0032);

    temp= temp - 2.5;

    temp= temp/.0084;

    temp= temp+27;

    sensores.temp.vtemp= temp;


   INPacket[13]= sensores.temp.dtemp[0];
   INPacket[14]= sensores.temp.dtemp[1];
   INPacket[15]= sensores.temp.dtemp[2];
   INPacket[16]= sensores.temp.dtemp[3]; 

	
    return temp;
}

void Posicion(void)
{

    Aceleracion(ref);

    velx[1]= velx[0]+ paccx+ ((sensores.accx.vaccx - paccx)/2);
    posx[1]= posx[0] + velx[0] + ((velx[1] - velx[0])/2);
    
    vely[1]= vely[0]+ paccy+ ((sensores.accy.vaccy - paccx)/2);
    posy[1]= posy[0] + vely[0] + ((vely[1] - vely[0])/2);

    paccx= sensores.accx.vaccx;
    paccy= sensores.accy.vaccy;

    velx[0]=velx[1];
    vely[0]=vely[1];

    posicion.posx.posx= posx[1];
    posicion.posy.posy= posy[1];

    
    INPacket[17]= posicion.posx.dposx[0];
    INPacket[18]= posicion.posx.dposx[1];
    INPacket[19]= posicion.posx.dposx[2];
    INPacket[20]= posicion.posx.dposx[3];

    INPacket[21]= posicion.posy.dposy[0];
    INPacket[22]= posicion.posy.dposy[1];
    INPacket[23]= posicion.posy.dposy[2];
    INPacket[24]= posicion.posy.dposy[3];

    if (sensores.accx.vaccx==0)   //we count the number of acceleration samples that equals cero
     { countx++;}
    else { countx =0;}
    if (countx>=25)          //if this number exceeds 25, we can assume that velocity is cero
    {
      velx[1]=0;
      velx[0]=0;
    }
    if (sensores.accy.vaccy==0)   //we do the same for the Y axis
    { county++;}
    else { county =0;}
    if (county>=25)
     {
       vely[1]=0;
       vely[0]=0;
     }

    posx[1]=posx[0];
    posy[1]=posy[0];

}


